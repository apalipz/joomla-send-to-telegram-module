<?php
defined('_JEXEC') or die;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Factory;

require_once __DIR__ . '/helper.php';

$modPath = Uri::base(true).'/modules/mod_send_telegram/';
$document = Factory::getDocument(); 
//$document->addScript($modPath.'assets/js/script.js');
$document->addStyleSheet($modPath . 'assets/css/style.css');

$variables = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        if (isset($_POST['sendtelegram'])) {
            $selectedId = isset($_POST['select']) ? $_POST['select'] : null;

            if (empty($selectedId)) {
                echo json_encode(['status' => 'error', 'message' => 'Please select an item to send.']);
            } else {
                $articles = ModSendTelegramHelper::getArticles();
                $selectedItem = null;
                foreach ($articles as $item) {
                    if ($item->id == $selectedId) {
                        $selectedItem = $item;
                        break;
                    }
                }

                if ($selectedItem) {
                    echo json_encode(['status' => 'success', 'message' => 'Article sent successfully!', 'data' => $selectedItem]);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Article not found.']);
                }
            }
            exit;
        }
    } else {
        if (isset($_POST['save'])) {
            $token = ModSendTelegramHelper::sanitizeInput($_POST['token']);
            $idchat = ModSendTelegramHelper::sanitizeInput($_POST['idchat']);
            if (!empty($token) && !empty($idchat)) {
                ModSendTelegramHelper::insertToken($token, $idchat);
                echo '<script>
                        if (window.history.replaceState) {
                            window.history.replaceState(null, null, window.location.href);
                        }
                      </script>';
            }
        }

        if (isset($_POST['submit'])) {
            $data = [
                'title' => $_POST['tArticle'],
                'ftext' => !empty($_POST['ftext']) ? $_POST['ftext'] . '.innerText' : '1',
                'etext' => !empty($_POST['etext']) ? $_POST['etext'] . '.innerText' : '1',
                'fulltext' => !empty($_POST['fulltext']) ? $_POST['fulltext'] . '.innerText' : '1',
                'fulltextchr' => !empty($_POST['fulltextchr']) ? (int) $_POST['fulltextchr'] : 250,
                'img_style' => !empty($_POST['img_style']) ? $_POST['img_style'] : '1',
                'img_src' => !empty($_POST['img_src']) ? $_POST['img_src'] . '.src' : '1',
                'read_more' => $_POST['read_more'],
                'chanel_name' => $_POST['chanel_name'],
                'send_url' => isset($_POST['send_url']) ? 1 : 0 // Add this line
            ];
            if (!empty($_POST['tArticle'])) {
                ModSendTelegramHelper::insertArticle($data);
                echo '<script>
                        if (window.history.replaceState) {
                            window.history.replaceState(null, null, window.location.href);
                        }
                      </script>';
            } else {
                echo "Please select an option.";
            }
        }

        if (isset($_POST['sendtelegram'])) {
            echo '<script type="text/javascript">
                    if (window.history.replaceState) {
                        window.history.replaceState(null, null, window.location.href);
                    }
                  </script>';
        }
    }
}

$articles = ModSendTelegramHelper::getArticles();
$tokenData = ModSendTelegramHelper::getToken();

if ($tokenData) {
    foreach ($tokenData as $val) {
        $variables['telegramToken'] = $val->token;
        $variables['telegramIdChat'] = $val->id_chat;
    }
}

$variables['articles'] = $articles;

require JModuleHelper::getLayoutPath('mod_send_telegram', 'default', $variables);
?>
