<?php
defined('_JEXEC') or die;
?>

<form method="post" class="row">
  <div class="form-group col-12">
    <label for="token"><?php echo JText::_('TOKEN_LABEL'); ?></label>
    <div class="input-group mb-3">
    <input type="text" name="token" required class="form-control">
    <div class="input-group-append">
    <i class="fas fa-info-circle"></i>  <a href="https://t.me/BotFather" target="_blank"><?php echo JText::_('TELEGRAM_BOT'); ?></a>
    </span>
      </div>
    </div>
    <div id="popover-token" class="popover-custom"></div>

    <label for="idchat"><?php echo JText::_('CHAT_ID_LABEL'); ?></label>
    <div class="input-group mb-3">
      <input type="number" name="idchat" required class="form-control">
      <div class="input-group-append">
          <i class="fas fa-info-circle"></i>  <a href="https://t.me/getmyid_bot" target="_blank"><?php echo JText::_('TELEGRAM_GET_ID'); ?></a>
        </span>
      </div>
    </div>
    <div id="popover-idchat" class="popover-custom"></div>
  </div>

  <br/>
	<input type="submit" name="save" class="btn btn-info" value="<?php echo JText::_('SAVE_BUTTON'); ?>">
  <?php echo JHtml::_('form.token'); ?>
</form>