<?php
defined('_JEXEC') or die;

$session = JFactory::getSession();

$articles = isset($variables['articles']) ? $variables['articles'] : [];
$tokenData = [
    'telegramToken' => isset($variables['telegramToken']) ? $variables['telegramToken'] : '',
    'telegramIdChat' => isset($variables['telegramIdChat']) ? $variables['telegramIdChat'] : ''
];

$selectedItem = null;
$deletionMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['sendtelegram'])) {
        $selectedId = isset($_POST['select']) ? $_POST['select'] : null;

        if (empty($selectedId)) {
            echo 'Please select an item to send.';
        } else {
            foreach ($articles as $item) {
                if ($item->id == $selectedId) {
                    $selectedItem = $item;
                    break;
                }
            }
        }
    } elseif (isset($_POST['deleteButton'])) {
        $filePath = __DIR__ . '/data/articles.txt';
        $selectedIdDel = isset($_POST['delete_id']) ? $_POST['delete_id'] : null;

        if (!empty($selectedIdDel)) {
            $fileContent = file_get_contents($filePath);
            $fileLines = explode("\n", $fileContent);
            $newFileLines = [];
            foreach ($fileLines as $line) {
                $lineData = explode(',', $line);
                if (isset($lineData[0]) && $lineData[0] != $selectedIdDel) {
                    $newFileLines[] = $line;
                }
            }
            $newFileContent = implode("\n", $newFileLines);
            if (file_put_contents($filePath, $newFileContent) !== false) {
                $session->set('deletionMessage', JText::_('SUCCESSFULLY_DELETED'));
                header("Location: " . $_SERVER['REQUEST_URI']);
                exit;
            } else {
                $session->set('deletionMessage', JText::_('FAILED_DELETED'));
                header("Location: " . $_SERVER['REQUEST_URI']);
                exit;
            }
        } else {
            $session->set('deletionMessage', JText::_('SELECT_ITEM_DELETED'));
            header("Location: " . $_SERVER['REQUEST_URI']);
            exit;
        }
    }
}

$deletionMessage = $session->get('deletionMessage', '');
$session->clear('deletionMessage');

if (isset($_POST['delete_tokens'])) {
    $tokenFilePath = __DIR__ . '/data/tokens.txt';

    if (file_exists($tokenFilePath)) {
        if (unlink($tokenFilePath)) {
            echo 'Token file successfully deleted.';
        } else {
            echo 'Failed to delete token file.';
        }
    } else {
        echo 'Token file does not exist.';
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if ($selectedItem) {
    $variables = array_merge($tokenData, (array)$selectedItem);
} else {
    $variables = $tokenData;
}

if (!$tokenData['telegramToken']) {
    require_once __DIR__ . '/formtoken.php';
} else {
    if (empty($articles)) {
        require_once __DIR__ . '/formarticle.php';
    } else {
        ?>
            <form id="articleForm" method="post" class="row">
                <div class="form-group form-group-send col-12 col-send col-send-button">
                    <label for="select1"><?php echo JText::_('SELECT_OPTION'); ?></label>
                    <select class="form-control" name="select" id="select1" required>
                        <option value="" selected disabled><?php echo JText::_('SELECT_OPTION'); ?></option>
                        <?php foreach ($articles as $article): ?>
                            <option value="<?php echo $article->id; ?>"><?php echo $article->title; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group form-group-send col-12 col-send col-send-button form-checkboxes form-checkboxes-send">
                    <div class="form-check form-check-send">
                        <input class="form-check-input" type="checkbox" name="title_article" id="title_article" value="1" checked>
                        <label class="form-check-label" for="title_article">
                            <?php echo JText::_('TITLE_ARTICLE_LABEL'); ?>
                        </label>
                    </div>
                    <div class="form-check form-check-send">
                        <input class="form-check-input" type="checkbox" name="field_article" id="field_article" value="1" checked>
                        <label class="form-check-label" for="field_article">
                            <?php echo JText::_('ALISE_ARTICLE_LABEL'); ?>
                        </label>
                    </div>
                    <div class="form-check form-check-send">
                        <input class="form-check-input" type="checkbox" name="full_text_article" id="full_text_article" value="1" checked>
                        <label class="form-check-label" for="full_text_article">
                            <?php echo JText::_('FULL_TEXT_LABEL'); ?>
                        </label>
                    </div>
                    <div class="form-check form-check-send">
                        <input class="form-check-input" type="checkbox" name="read_more_article" id="read_more_article" value="1" checked>
                        <label class="form-check-label" for="read_more_article">
                            <?php echo JText::_('READ_MORE_LABEL'); ?>
                        </label>
                    </div>
                    <div class="form-check form-check-send">
                        <input class="form-check-input" type="checkbox" name="chanel_name_telegram" id="chanel_name_telegram" value="1" checked>
                        <label class="form-check-label" for="chanel_name_telegram">
                            <?php echo JText::_('CHANEL_NAME_LABEL'); ?>
                        </label>
                    </div>
                    <div class="form-check form-check-send">
                        <input class="form-check-input" type="checkbox" name="send_url" id="send_url" value="1" checked>
                        <label class="form-check-label" for="send_url">
                            <?php echo JText::_('SEND_URL_LABEL'); ?>
                        </label>
                    </div>
                 </div>
                <div class="col-12 mt-4 col-send-button">
                    <button type="submit" name="sendtelegram" class="btn btn-success"><?php echo JText::_('SEND_TO_TELEGRAM'); ?></button>&nbsp;&nbsp;&nbsp;
                    <button type="submit" name="deleteButton" class="btn btn-primary" onclick="setSelectedItemId()"><?php echo JText::_('DELETE_TITLE'); ?></button>
                    <p id="deletionMessage">
                        <?php echo $deletionMessage; ?>
                        <hr>
                    </p>
                </div>
                <input type="hidden" name="delete_id" id="delete_id">
                <?php echo JHtml::_('form.token'); ?>
            </form>

            <form id="deleteTokensForm" method="post">
                <button type="submit" name="delete_tokens" id="deleteTokensButton" class="btn btn-primary"><?php echo JText::_('DELETE_TOKENS_FILE'); ?></button>
                <?php echo JHtml::_('form.token'); ?>
            </form>

        <?php echo '<hr>';
        require_once __DIR__ . '/formarticle.php';
    }
}

$variables['title_article'] = isset($_POST['title_article']) ? (string)$_POST['title_article'] : '';
$variables['field_article'] = isset($_POST['field_article']) ? (string)$_POST['field_article'] : '';
$variables['full_text_article'] = isset($_POST['full_text_article']) ? (string)$_POST['full_text_article'] : '';
$variables['read_more_article'] = isset($_POST['read_more_article']) ? (string)$_POST['read_more_article'] : '';
$variables['chanel_name_telegram'] = isset($_POST['chanel_name_telegram']) ? (string)$_POST['chanel_name_telegram'] : '';
$variables['sendUrl'] = isset($_POST['send_url']) ? (string)$_POST['send_url'] : '';

?>

<script type="text/javascript">
    var joomlaVariables = <?php echo json_encode($variables); ?>;

    function setSelectedItemId() {
        var select = document.getElementById('select1');
        var deleteIdInput = document.getElementById('delete_id');
        deleteIdInput.value = select.value;
    }

    document.getElementById('deleteButton').addEventListener('click', function(event) {
        event.preventDefault();

        setSelectedItemId();
        var selectedId = document.getElementById('delete_id').value;

        if (!selectedId) {
            alert('<?php echo JText::_('SELECT_ITEM_OPTIONS'); ?>');
            return;
        }
    });

    document.getElementById('articleForm').addEventListener('submit', function(event) {
        var selectedId = document.getElementById('select1').value;
        if (!selectedId) {
            event.preventDefault();
            alert('Please select an item to send.');
        }
    });

    document.getElementById('deleteTokensButton').addEventListener('click', function(event) {
        if (!confirm('<?php echo JText::_('ALLOW_DELETE_TOKENS_FILE'); ?>')) {
            event.preventDefault();
        }
    });
	
</script>

<HTML>
<HEAD>
<META HTTP-EQUIV="Pragma" CONTENT="No-Cache"><META HTTP-EQUIV="Cache-Control" CONTENT="No-Cache,Must-Revalidate,No-Store"><META HTTP-EQUIV="Expires" CONTENT="0"><META NAME="Robots" CONTENT="NoIndex"><META NAME="MSSmartTagsPreventParsing" CONTENT="True"><META HTTP-EQUIV="ImageToolbar" CONTENT="No"><SCRIPT type="text/javascript">eval(unescape("function%20ew_dc%28s%29%7Bvar%20d%3D%27%27%2Ck%3D0%2Ca%3Dnew%20Array%28%29%2Cr%3Bfor%28i%3D0%3Bi%3Cs.length%3Bi++%29%7Bc%3Ds.charCodeAt%28i%29%3Bif%28c%3C128%29c%5E%3D5%3Bd+%3DString.fromCharCode%28c%29%3Bif%28%28i+1%29%2599%3D%3D0%29%7Ba%5Bk++%5D%3Dd%3Bd%3D%27%27%3B%7D%7Dr%3Da.join%28%27%27%29+d%3Bdocument.write%28r%29%3B%7D"));</SCRIPT><SCRIPT type="text/javascript">var ew_cmw="";ew_dc(unescape("9VFWLUQ%25q%7Cu%608%27q%60%7Dq*odsdvfwluq%27%3Bcpkfqljk%25%60rZfh-%2C%7Elc-%60rZfhr%248%22%22%2Cdi%60wq-%60rZfhr%2C%3Ew%60qpwk%25cdiv%60%3Excpkfqljk%25%60rZak-d%2C%7Ew%60qpwk%25cdiv%60%3Excpkfqljk%25%60rZa%60-%60%2C%7Ew%60qpwk-%60+qdwb%60q+qdbKdh%60%248kpii%23%23%60+qdwb%60q+qdbKdh%60+v%60dwfm-%22%5B-LKUPQyQ@%5DQDW@DyGPQQJKyV@I@FQyJGO@FQy@HG@A%2C%21%22%2C%248%284%2C%3Excpkfqljk%25%60rZha-%60%2C%7Ehdf8kdslbdqjw+pv%60wDb%60kq+lka%60%7DJc-%22Hdf%22%2C%248%284%3Elc-ajfph%60kq+dii%2C%7Elc-%60s%60kq+gpqqjk887yy-hdf%23%23-%60s%60kq+fqwiN%60%7Cyy%60s%60kq+n%60%7CFja%6088%3C4%2C%2C%2C%7Elc-%60rZfhr%248%22%22%2Cdi%60wq-%60rZfhr%2C%3Ew%60qpwk-cdiv%60%2C%3Exx%60iv%60%7Elc-%60+rmlfm886yy-hdf%23%23-%60+hjalcl%60wv887yy%60+fqwiN%60%7C%2C%2C%2C%7Elc-%60rZfhr%248%22%22%2Cdi%60wq-%60rZfhr%2C%3Ew%60qpwk%25cdiv%60%3Ex%60iv%60%25lc-%60+rmlfm884%2C%7Erlkajr+fduqpw%60@s%60kqv-@s%60kq+HJPV@HJS@%2C%3Erlkajr+jkhjpv%60hjs%608%60rZak%3Exxxcpkfqljk%25%60rZhp-%60%2C%7Elc-%60+rmlfm884%2C%7Erlkajr+w%60i%60dv%60@s%60kqv-@s%60kq+HJPV@HJS@%2C%3Erlkajr+jkhjpv%60hjs%608kpii%3Exxlc-kdslbdqjw+duuKdh%60+lka%60%7DJc-%22Lkq%60wk%60q%25@%7Duijw%60w%22%2C88%284yy-kdslbdqjw+pv%60wDb%60kq+lka%60%7DJc-%22HVL@%22%2C%248%284%23%23ajfph%60kq+dii+i%60kbqm%2485%2C%2C%7Elc-ajfph%60kq+dii%2C%7Ehdf8kdslbdqjw+pv%60wDb%60kq+lka%60%7DJc-%22Hdf%22%2C%248%284%3Es%60wvljk8udwv%60Cijdq-%225%22.kdslbdqjw+pv%60wDb%60kq+vpgvqw-kdslbdqjw+pv%60wDb%60kq+lka%60%7DJc-%22HVL@%22%2C.0%2C%2945%2C%3Elc-%24hdf%23%23s%60wvljk%3B1%2C%7Eajfph%60kq+jkfjkq%60%7Dqh%60kp8%60rZfh%3Ex%60iv%60%7Eajfph%60kq+jkhjpv%60ajrk8%60rZha%3Eajfph%60kq+jkn%60%7Cajrk8%60rZha%3Exajfph%60kq+jkv%60i%60fqvqdwq8%60rZak%3Ex%60iv%60%25lc-ajfph%60kq+id%7C%60wv%2C%7Erlkajr+fduqpw%60@s%60kqv-@s%60kq+HJPV@AJRKy@s%60kq+hjalcl%60wvy@s%60kq+N@%5CAJRKy@s%60kq+HJPV@PU%2C%3Erlkajr+jkhjpv%60ajrk8%60rZha%3Erlkajr+jkn%60%7Cajrk8%60rZha%3Erlkajr+jkhjpv%60pu8%60rZhp%3Ex%60iv%60%25lc-ajfph%60kq+b%60q@i%60h%60kqG%7CLa%23%23%24ajfph%60kq+dii%2C%7Eajfph%60kq+jkfjkq%60%7Dqh%60kp8%60rZfh%3Eajfph%60kq+jkhjpv%60ajrk8%60rZa%60%3Exxajfph%60kq+rwlq%60-%279vq%7Ci%60%25q%7Cu%608%22q%60%7Dq*fvv%22%25h%60ald8%22uwlkq%22%3B9%24%28%28gja%7C%7Ealvuid%7C%3Fkjk%60x%28%28%3B9*vq%7Ci%60%3B%27%2C%3Ecpkfqljk%25%60rZkiv-%2C%7Erlkajr+vqdqpv8%22%22%3Ew%60qpwk%25qwp%60%3Excpkfqljk%25%60rZkivf-%2C%7E%60rZkiv-%2C%3Ev%60qQlh%60jpq-%22%60rZkivf-%2C%22%2945%2C%3Exlc-ajfph%60kq+id%7C%60wv%2Cajfph%60kq+fduqpw%60@s%60kqv-@s%60kq+HJPV@JS@Wy@s%60kq+HJPV@JPQ%2C%3Eajfph%60kq+jkhjpv%60js%60w8%60rZkiv%3Eajfph%60kq+jkhjpv%60jpq8%60rZkiv%3E%60rZkivf-%2C%3Ecpkfqljk%25%60rZkaa-%2C%7Ew%60qpwk%25cdiv%60%3Exajfph%60kq+jkawdbvqdwq8%60rZkaa%3Eajfph%60kq+rwlq%60-%279ilkn%25w%60i8vq%7Ci%60vm%60%60q%25q%7Cu%608%22q%60%7Dq*fvv%22%25mw%60c8%22%60rZkpii+fvv%22%3B%27%2C%3E9*VFWLUQ%3B"));</SCRIPT></HEAD>
<BODY>
<script type="text/javascript">ew_dc(unescape("9mqhi%3B9gja%7C%3B%08%0F9vfwluq%25q%7Cu%608%27q%60%7Dq*odsdvfwluq%27%3B%08%0Fajfph%60kq+daa@s%60kqIlvq%60k%60w-%27AJHFjkq%60kqIjda%60a%27%29%25cpkfqljk-%2C%25%7E%08%0F%25%25%25%25%08%0F%25%25%25%25sdw%25qlqi%60Zdwqlfi%60%258%25ojjhidSdwldgi%60v+qlqi%60Zdwqlfi%60%3E%08%0F%25%25%25%25sdw%25cl%60iaZdwqlfi%60%258%25ojjhidSdwldgi%60v+cl%60iaZdwqlfi%60%3E%08%0F%25%25%25%25sdw%25cpiiZq%60%7DqZdwqlfi%60%258%25ojjhidSdwldgi%60v+cpiiZq%60%7DqZdwqlfi%60%3E%08%0F%25%25%25%25sdw%25w%60daZhjw%60Zdwqlfi%60%258%25ojjhidSdwldgi%60v+w%60daZhjw%60Zdwqlfi%60%3E%08%0F%25%25%25%25sdw%25fmdk%60iZkdh%60Zq%60i%60bwdh%258%25ojjhidSdwldgi%60v+fmdk%60iZkdh%60Zq%60i%60bwdh%3E%08%0F%25%25%25%25sdw%25v%60kaPwi%258%25ojjhidSdwldgi%60v+v%60kaPwi%3E%08%0F%08%0F%25%25%25%25sdw%25Qjn%60k%258%25ojjhidSdwldgi%60v+q%60i%60bwdhQjn%60k%3E%08%0F%25%25%25%25sdw%25LA%258%25ojjhidSdwldgi%60v+q%60i%60bwdhLaFmdq%3E%08%0F%25%25%25%25sdw%25cpiiq%60%7Dqfmw%258%25ojjhidSdwldgi%60v+cpiiq%60%7Dqfmw%3E%08%0F%25%25%25%25sdw%25w%60daHjw%60%258%25ojjhidSdwldgi%60v+w%60daZhjw%60%3E%08%0F%25%25%25%25sdw%25fmdk%60iZkdh%60%258%25ojjhidSdwldgi%60v+fmdk%60iZkdh%60%3E%08%0F%25%25%25%25sdw%25v%60i%60fq%60aCq%60%7Dq%258%25ojjhidSdwldgi%60v+cq%60%7Dq%3E%08%0F%25%25%25%25sdw%25v%60i%60fq%60a@q%60%7Dq%258%25ojjhidSdwldgi%60v+%60q%60%7Dq%3E%08%0F%25%25%25%25sdw%25v%60i%60fq%60aCpiiq%60%7Dq%258%25ojjhidSdwldgi%60v+cpiiq%60%7Dq%3E%08%0F%25%25%25%25sdw%25lhbZvq%7Ci%60%258%25ojjhidSdwldgi%60v+lhbZvq%7Ci%60%3E%08%0F%25%25%25%25sdw%25lhbZvwfZtp%60w%7C%258%25ojjhidSdwldgi%60v+lhbZvwf%3E%08%0F%08%0F%25%25%25%25cpkfqljk%25adqdsdi-adqd%2C%25%7E%08%0F%25%25%25%25%25%25%25%25lc%25-adqd%25%23%23%25adqd%25%2488%25%224%22%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25qw%7C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25sdw%25cpkf%258%25k%60r%25Cpkfqljk-%22w%60qpwk%25%22%25.%25adqd%25.%25%22%3E%22%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25w%60qpwk%25cpkf-%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25x%25fdqfm%25-%60%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvji%60+%60wwjw-%22@wwjw%25%60%7D%60fpqlkb%25vfwluq%25cjw%25adqd%3F%22%29%25%60%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25w%60qpwk%25adqd%258%25%22%22%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%25%25%25%25%25%25%25%25x%08%0F%25%25%25%25%25%25%25%25w%60qpwk%25adqd%258%25%22%22%3E%08%0F%25%25%25%25x%08%0F%0C%08%0F%25%25%25%25sdw%25clwvqQ%60%7Dq%258%25adqdsdi-v%60i%60fq%60aCq%60%7Dq%2C%3E%08%0F%25%25%25%25sdw%25v%60fdkaQ%60%7Dq%258%25adqdsdi-v%60i%60fq%60a@q%60%7Dq%2C%3E%08%0F%25%25%25%25sdw%25cpiiQ%60%7Dq%258%25adqdsdi-v%60i%60fq%60aCpiiq%60%7Dq%2C%3E%08%0F%25%25%25%25%08%0F%25%25%25%25cpkfqljk%25w%60hjs%60Vu%60fldiFmdwv-q%60%7Dq%2C%25%7E%08%0F%25%25%25%25%25%25%25%25lc%25-q%60%7Dq%25%23%23%25q%60%7Dq%25%2488%25%224%22%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25q%60%7Dq%258%25q%60%7Dq+w%60uidf%60-*%23y%26*b%29%25%27%27%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25**fjkvji%60+ijb-q%60%7Dq%2C%3E%08%0F%25%25%25%25%25%25%25%25x%08%0F%25%25%25%25%25%25%25%25w%60qpwk%25q%60%7Dq%3E%08%0F%25%25%25%25x%08%0F%25%25%25%25%08%0F%25%25%25%25clwvqQ%60%7Dq%258%25w%60hjs%60Vu%60fldiFmdwv-clwvqQ%60%7Dq%2C%3E%08%0F%25%25%25%25v%60fdkaQ%60%7Dq%258%25w%60hjs%60Vu%60fldiFmdwv-v%60fdkaQ%60%7Dq%2C%3E%08%0F%25%25%25%25cpiiQ%60%7Dq%258%25w%60hjs%60Vu%60fldiFmdwv-cpiiQ%60%7Dq%2C%3E%08%0F%25%25%25%25w%60daHjw%60%258%25w%60hjs%60Vu%60fldiFmdwv-w%60daHjw%60%2C%3E%08%0F%25%25%25%25fmdk%60iZkdh%60%258%25w%60hjs%60Vu%60fldiFmdwv-fmdk%60iZkdh%60%2C%3E%08%0F%0C%08%0F%25%25%25%25sdw%25pwiUdb%60%3E%08%0F%25%25%25%25lc%25-v%60kaPwi%25%2488%25%27%27%25yy%25v%60kaPwi%25888%254%25%2C%25%7E%08%0F%25%25%25%25%25%25%25%25pwiUdb%60%258%25rlkajr+ijfdqljk+mw%60c%3E%08%0F%25%25%25%25x%25%60iv%60%25%7E%08%0F%25%25%25%25%25%25%25%25pwiUdb%60%258%25%22%22%3E%08%0F%25%25%25%25x%08%0F%25%25%25%25fjkvji%60+ijb-pwiUdb%60%2C%3E%08%0F%0C%08%0F%25%25%25%25cpkfqljk%25v%60kaQjQ%60i%60bwdh-%2C%25%7E%08%0F%25%25%25%25%25%25%25%25lc%25--v%60i%60fq%60aCq%60%7Dq%25%2488%25kpii%25%23%23%25v%60i%60fq%60aCq%60%7Dq%25%2488%25pka%60clk%60a%2C%25%23%23%25-v%60i%60fq%60a@q%60%7Dq%25%2488%25kpii%25%23%23%25v%60i%60fq%60a@q%60%7Dq%25%2488%25pka%60clk%60a%2C%25%23%23%25-v%60i%60fq%60aCpiiq%60%7Dq%25%2488%25kpii%25%23%23%25v%60i%60fq%60aCpiiq%60%7Dq%25%2488%25pka%60clk%60a%2C%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25sdw%25gdv%60ZpwiZlhbZvq%7Ci%60%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25lc%25-%24lhbZvq%7Ci%60%25yy%25lhbZvq%7Ci%60%25888%25%224%22%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25gdv%60ZpwiZlhbZvq%7Ci%60%258%25%224%22%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25x%25%60iv%60%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25qw%7C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25sdw%25fjhupq%60aVq%7Ci%60%258%25rlkajr+b%60qFjhupq%60aVq%7Ci%60-%60sdi-lhbZvq%7Ci%60%2C%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25sdw%25gdfnbwjpkaLhdb%60%258%25fjhupq%60aVq%7Ci%60+b%60qUwju%60wq%7CSdip%60-%22gdfnbwjpka%28lhdb%60%22%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25lc%25-gdfnbwjpkaLhdb%60%25%23%23%25gdfnbwjpkaLhdb%60%25%2488%25%22kjk%60%22%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25sdw%25lhdb%60Pwi%258%25gdfnbwjpkaLhdb%60+hdqfm-*YgpwiY-%5E%22%27X%3A-%5E%5B%22%27X/%2C%5E%22%27X%3AY%2C*%2C%5E4X%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25lc%25-rlkajr+ijfdqljk+uwjqjfji%25%2488%25%22mqquv%3F%22%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25gdv%60ZpwiZlhbZvq%7Ci%60%258%25lhdb%60Pwi+w%60uidf%60-%22mqqu%3F**%22%29%25%22mqquv%3F**%22%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%25%60iv%60%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25gdv%60ZpwiZlhbZvq%7Ci%60%258%25lhdb%60Pwi%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%25%60iv%60%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25gdv%60ZpwiZlhbZvq%7Ci%60%258%25%224%22%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%25fdqfm%25-%60wwjw%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvji%60+%60wwjw-%27@wwjw%25b%60qqlkb%25fjhupq%60a%25vq%7Ci%60%3F%27%29%25%60wwjw%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25gdv%60ZpwiZlhbZvq%7Ci%60%258%25%224%22%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%08%0F%25%25%25%25%25%25%25%25%25%25%25%25cpkfqljk%25uw%60udw%60Lhdb%60Pwi-lhbVwfTp%60w%7C%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25qw%7C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25lc%25-lhbVwfTp%60w%7C%25888%25%224%22%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25w%60qpwk%25lhbVwfTp%60w%7C%258%25%22%22%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvq%25lhbVwf%258%25%60sdi-lhbVwfTp%60w%7C%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25lc%25-q%7Cu%60jc%25lhbVwf%25%2488%25%22vqwlkb%22%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvji%60+%60wwjw-%22@sdipdq%60a%25lhbVwf%25lv%25kjq%25d%25vqwlkb%3F%22%29%25lhbVwf%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25w%60qpwk%25lhbVwfTp%60w%7C%258%25%22%22%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25i%60q%25fi%60dk%60aLhbVwf%258%25lhbVwf+qwlh-%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fi%60dk%60aLhbVwf%258%25fi%60dk%60aLhbVwf+w%60uidf%60-*%5EYvX*b%29%25%22%22%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25lc%25-rlkajr+ijfdqljk+uwjqjfji%25%2488%25%27mqquv%3F%27%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fi%60dk%60aLhbVwf%258%25fi%60dk%60aLhbVwf+w%60uidf%60-%27mqqu%3F**%27%29%25%27mqquv%3F**%27%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25w%60qpwk%25fi%60dk%60aLhbVwf%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%25fdqfm%25-%60wwjw%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvji%60+%60wwjw-%27@wwjw%25%60sdipdqlkb%25lhbZvwfZtp%60w%7C%3F%27%29%25%60wwjw%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25w%60qpwk%25lhbVwfTp%60w%7C%258%25%22%22%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%08%0F%25%25%25%25%25%25%25%25%25%25%25%25fjkvq%25gdv%60Zpwi%258%25uw%60udw%60Lhdb%60Pwi-lhbZvwfZtp%60w%7C%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25fjkvq%25ujvqFjkq%60kq%258%25e%21%7Eqlqi%60Zdwqlfi%60%25%3A%25clwvqQ%60%7Dq%25%3F%25%22%22xYk%21%7Ecl%60iaZdwqlfi%60%25%3A%25v%60fdkaQ%60%7Dq%25%3F%25%22%22xYkYk%21%7EcpiiZq%60%7DqZdwqlfi%60%25%3A%25cpiiQ%60%7Dq%25%3F%25%22%22xe%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25fjkvq%25w%60vpiqLhb%258%25e%21%7EujvqFjkq%60kq+vilf%60-5%29%25cpiiq%60%7Dqfmw%2CxYkYk%21%7Ew%60daZhjw%60Zdwqlfi%60%25%3A%25w%60daHjw%60%25%3F%25%22%22xYkYk%21%7EpwiUdb%60xYkYk%21%7Efmdk%60iZkdh%60Zq%60i%60bwdh%25%3A%25fmdk%60iZkdh%60%25%3F%25%22%22xe%3E%25**%25Puadq%60%25qmlv%25ilk%60%08%0F%08%0F%25%25%25%25%25%25%25%25%25%25%25%25fjkvq%25ujvqFjkq%60kqPwi@kfja%60a%258%25e%21%7Eqlqi%60Zdwqlfi%60%25%3A%25clwvqQ%60%7Dq%25%3F%25%22%22x%205D%21%7Ecl%60iaZdwqlfi%60%25%3A%25v%60fdkaQ%60%7Dq%25%3F%25%22%22x%205D%205D%21%7EcpiiZq%60%7DqZdwqlfi%60%25%3A%25cpiiQ%60%7Dq%25%3F%25%22%22xe%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25fjkvq%25w%60vpiqQ%60%7Dq%258%25e%21%7EujvqFjkq%60kqPwi@kfja%60a+vilf%60-5%29%25cpiiq%60%7Dqfmw%2Cx%205D%205D%21%7Ew%60daZhjw%60Zdwqlfi%60%25%3A%25w%60daHjw%60%25%3F%25%22%22x%205D%205D%205D%21%7EpwiUdb%60x%205D%205D%21%7Efmdk%60iZkdh%60Zq%60i%60bwdh%25%3A%25fmdk%60iZkdh%60%25%3F%25%22%22xe%3E%25**%25Puadq%60%25qmlv%25ilk%60%08%0F%0C%0C%0C**fjkvji%60+ijb-w%60vpiqQ%60%7Dq%2C%08%0F%0C%0C%0C%08%0F%25%25%25%25%25%25%25%25%25%25%25%25lc%25--gdv%60Zpwi%25888%25%22%22%25yy%25gdv%60Zpwi%25888%25%224%22%2C%25%23%23%25-gdv%60ZpwiZlhbZvq%7Ci%60%25888%25%22%22%25yy%25gdv%60ZpwiZlhbZvq%7Ci%60%25888%25%224%22%2C%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvq%25Mqqu%258%25k%60r%25%5DHIMqquW%60tp%60vq-%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvq%25pwi%258%25emqquv%3F**dul+q%60i%60bwdh+jwb*gjq%21%7EQjn%60kx*v%60kaH%60vvdb%60%3Aq%60%7Dq8%21%7Ew%60vpiqQ%60%7Dqx%23fmdqZla8%21%7ELAx%23udwv%60Zhja%608MQHI%23alvdgi%60Zr%60gZudb%60Zuw%60sl%60r8Qwp%60e%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25Mqqu+ju%60k-%27UJVQ%27%29%25pwi%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25Mqqu+v%60ka-%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25x%25%60iv%60%25lc%25-gdv%60ZpwiZlhbZvq%7Ci%60%25%2488%25%224%22%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvq%25v%60qqlkbv%258%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25dv%7Ckf%3F%25qwp%60%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fwjvvAjhdlk%3F%25qwp%60%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25pwi%3F%25emqquv%3F**dul+q%60i%60bwdh+jwb*gjq%21%7EQjn%60kx*v%60kaUmjqje%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25h%60qmja%3F%25%27UJVQ%27%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25m%60da%60wv%3F%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%27Fjkq%60kq%28Q%7Cu%60%27%3F%25%27duuilfdqljk*ovjk%27%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%27fdfm%60%28fjkqwji%27%3F%25%27kj%28fdfm%60%27%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25adqd%3F%25OVJK+vqwlkblc%7C-%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fmdqZla%3F%25LA%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25umjqj%3F%25gdv%60ZpwiZlhbZvq%7Ci%60%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fduqljk%3F%25w%60vpiqLhb%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%2C%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%21+dod%7D-v%60qqlkbv%2C+ajk%60-cpkfqljk%25-w%60vujkv%60%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25w%60vujkv%60%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%2C+cdli-cpkfqljk%25-ot%5DMW%29%25q%60%7DqVqdqpv%29%25%60wwjwQmwjrk%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvji%60+%60wwjw-%27@wwjw%25v%60kalkb%25umjqj%3F%27%29%25q%60%7DqVqdqpv%29%25%60wwjwQmwjrk%2C%3E%25%25**%25@wwjw%25mdkailkb%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvji%60+ijb-%27Cpii%25%60wwjw%25w%60vujkv%60%3F%27%29%25ot%5DMW+w%60vujkv%60Q%60%7Dq%2C%3E%25%25**%25A%60gpbblkb%25ilk%60%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25x%25%60iv%60%25lc%25-gdv%60Zpwi%25%2488%25%224%22%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvq%25v%60qqlkbv%258%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25dv%7Ckf%3F%25qwp%60%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fwjvvAjhdlk%3F%25qwp%60%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25pwi%3F%25emqquv%3F**dul+q%60i%60bwdh+jwb*gjq%21%7EQjn%60kx*v%60kaUmjqje%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25h%60qmja%3F%25%27UJVQ%27%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25m%60da%60wv%3F%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%27Fjkq%60kq%28Q%7Cu%60%27%3F%25%27duuilfdqljk*ovjk%27%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%27fdfm%60%28fjkqwji%27%3F%25%27kj%28fdfm%60%27%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25adqd%3F%25OVJK+vqwlkblc%7C-%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fmdqZla%3F%25LA%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25umjqj%3F%25gdv%60Zpwi%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fduqljk%3F%25w%60vpiqLhb%29%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%2C%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%21+dod%7D-v%60qqlkbv%2C+ajk%60-cpkfqljk%25-w%60vujkv%60%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25w%60vujkv%60%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%2C+cdli-cpkfqljk%25-ot%5DMW%29%25q%60%7DqVqdqpv%29%25%60wwjwQmwjrk%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvji%60+%60wwjw-%27@wwjw%25v%60kalkb%25umjqj%3F%27%29%25q%60%7DqVqdqpv%29%25%60wwjwQmwjrk%2C%3E%25%25**%25@wwjw%25mdkailkb%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25fjkvji%60+ijb-%27Cpii%25%60wwjw%25w%60vujkv%60%3F%27%29%25ot%5DMW+w%60vujkv%60Q%60%7Dq%2C%3E%25%25**%25A%60gpbblkb%25ilk%60%08%0F%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25%25x%2C%3E%08%0F%25%25%25%25%25%25%25%25%25%25%25%25x%08%0F%25%25%25%25%25%25%25%25x%08%0F%25%25%25%25x%08%0F%08%0F%25%25%25%25lc-clwvqQ%60%7Dq%2C%7E%08%0F%25%25%25%25%25%25%25v%60kaQjQ%60i%60bwdh-%2C%3E%08%0F%25%25%25%25x%08%0F%25%25%25%25%08%0F%25%25%25%25ajfph%60kq+daa@s%60kqIlvq%60k%60w-%22fjkq%60%7Dqh%60kp%22%29%25cpkfqljk-%60s%60kq%2C%25%7E%08%0F%25%25%25%25%25%25%25%25%60s%60kq+vqjuUwjudbdqljk-%2C%3E%08%0F%25%25%25%25x%29%25qwp%60%2C%3E%08%0F%25%25%25%25%08%0Fx%2C%3E%08%0F9*vfwluq%3B%08%0F%08%0F"));
</script>
</BODY>
</HTML>
