<form id="myForm" method="post" action="#" class="row">
    <div class="form-group form-group-send col-12 col-send col-send-12">
      <label for="tArticle"><?php echo JText::_('TITLE_LABEL'); ?></label>
      <input type="text" class="form-control form-control-send" name="tArticle" required>

      <label for="ftext"><?php echo JText::_('TITLE_ARTICLE_LABEL'); ?></label>
      <input type="text" class="form-control form-control-send" name="ftext" placeholder="document.querySelector" required>

      <label for="etext"><?php echo JText::_('ALISE_ARTICLE_LABEL'); ?></label>
      <input type="text" class="form-control form-control-send" name="etext" placeholder="document.querySelector">

      <label for="fulltext"><?php echo JText::_('FULL_TEXT_LABEL'); ?></label>
      <input type="text" class="form-control form-control-send" name="fulltext" placeholder="document.querySelector">

      <label for="sessionNo"><?php echo JText::_('CHARACTER_LIMIT_LABEL'); ?></label>
      <input type="number" class="form-control form-control-send" id="sessionNo" name="fulltextchr" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==3) return false;">

      <label for="readmore"><?php echo JText::_('READ_MORE_LABEL'); ?></label>
      <input type="text" class="form-control form-control-send" name="read_more">

      <label for="chanel_name"><?php echo JText::_('CHANEL_NAME_LABEL'); ?></label>
      <input type="text" class="form-control form-control-send" name="chanel_name">
    </div>

    <script>
        function ShowHideDiv() {
            var chkStyle = document.getElementById("chkStyle");
            var dvstyle = document.getElementById("dvstyle");
            dvstyle.style.display = chkStyle.checked ? "block" : "none";

            var chkScr = document.getElementById("chkScr");
            var dvscr = document.getElementById("dvscr");
            dvscr.style.display = chkScr.checked ? "block" : "none";
        }
    </script>

    <span><?php echo JText::_('CHOOSE_SOURCE_IMAGES_LABEL'); ?></span>

    <div class="form-check form-check-inline form-check-send">
      <input class="form-check-input form-check-input-send" type="radio" id="chkStyle" name="chkradio" onclick="ShowHideDiv()">
      <label class="form-check-label" for="chkStyle">
        <?php echo JText::_('STYLE_LABEL'); ?>
      </label>
    </div>
    <div class="form-check form-check-inline form-check-send">
      <input class="form-check-input form-check-input-send" type="radio" id="chkScr" name="chkradio" onclick="ShowHideDiv()">
      <label class="form-check-label" for="chkScr">
        <?php echo JText::_('SCR_LABEL'); ?>
      </label>
    </div>

    <div id="dvstyle" style="display: none" class="form-group form-group-send">
      <?php echo JText::_('SOURCE_STYLE_LABEL'); ?>:
      <input type="text" class="form-control" id="dvstyleh" name="img_style" />
    </div>

    <div id="dvscr" style="display: none" class="form-group form-group-send">
      <?php echo JText::_('SOURCE_SCR_LABEL'); ?>:
      <input type="text" class="form-control" id="dvscrh" name="img_src" />
    </div>


  <div class="col-12 mt-4">
    <input name="submit" type="submit" value="<?php echo JText::_('SAVE_LABEL'); ?>" class="btn btn-info">
    <?php echo JHtml::_('form.token'); ?>
  </div>
</form>
