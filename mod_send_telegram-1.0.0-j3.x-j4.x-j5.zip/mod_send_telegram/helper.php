<?php
defined('_JEXEC') or die;
use Joomla\CMS\Factory;

define('ENCRYPTION_KEY', '95824763280452786012547859622901'); // 32 characters for AES-256-CBC
define('ENCRYPTION_IV', '3791583709580379'); // 16 characters for AES-256-CBC

    
class ModSendTelegramHelper
{
    private static $tokenFile = __DIR__ . '/tmpl/data/tokens.txt';
    private static $articleFile = __DIR__ . '/tmpl/data/articles.txt';
    
    public static function initialize() {
        if (!file_exists(self::$tokenFile)) {
            if (!file_exists(__DIR__ . '/tmpl/data')) {
                mkdir(__DIR__ . '/tmpl/data', 0777, true);
            }
            file_put_contents(self::$tokenFile, '');
        }
        if (!file_exists(self::$articleFile)) {
            file_put_contents(self::$articleFile, '');
        }
    }

    public static function encryptData($data) {
        return openssl_encrypt($data, 'aes-256-cbc', ENCRYPTION_KEY, 0, ENCRYPTION_IV);
    }
    
    public static function decryptData($data) {
        return openssl_decrypt($data, 'aes-256-cbc', ENCRYPTION_KEY, 0, ENCRYPTION_IV);
    }
    
    public static function sanitizeInput($data)
    {
        return htmlspecialchars(strip_tags(trim($data)));
    }

    public static function insertToken($token, $idchat) {
        $encryptedToken = self::encryptData($token);
        $encryptedIdChat = self::encryptData($idchat);
        $data = "$encryptedToken,$encryptedIdChat\n";
        file_put_contents(self::$tokenFile, $data, FILE_APPEND);
    }

    public static function getToken() {
        if (!file_exists(self::$tokenFile)) {
            return [];
        }

        $tokens = [];
        $lines = file(self::$tokenFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            list($encryptedToken, $encryptedIdChat) = explode(',', $line);
            $tokens[] = (object) [
                'token' => self::decryptData($encryptedToken),
                'id_chat' => self::decryptData($encryptedIdChat),
            ];
        }

        return $tokens;
    }

    public static function rewriteArticlesFile($articles)
    {
        $content = file(self::$articleFile);
        foreach ($content as $key => $line) {
            $fields = explode(',', $line);
            if (in_array($fields[0], array_column($articles, 'id'))) {
                unset($content[$key]);
            }
        }
        file_put_contents(self::$articleFile, implode('', $content));
    }

    public static function insertArticle($data)
    {
        $id = uniqid();
        array_unshift($data, $id);
        $line = implode(',', $data) . "\n";
        file_put_contents(self::$articleFile, $line, FILE_APPEND);
    }

    public static function getArticles()
    {
        if (!file_exists(self::$articleFile)) {
            return [];
        }

        $articles = [];
        $lines = file(self::$articleFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $fields = explode(',', $line);
            $articles[] = (object) [
                'id' => $fields[0],
                'title' => $fields[1],
                'ftext' => $fields[2],
                'etext' => $fields[3],
                'fulltext' => $fields[4],
                'fulltextchr' => $fields[5],
                'img_style' => $fields[6],
                'img_src' => $fields[7],
                'read_more' => $fields[8],
                'chanel_name' => $fields[9],
            ];
        }

        return $articles;
    }
}

ModSendTelegramHelper::initialize();
?>
